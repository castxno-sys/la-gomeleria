import { Link, NavLink } from 'react-router-dom'
import { usePedido } from '../context/PedidoContext.jsx'
import { negocio } from '../data/menu.js'
import { plural } from '../utils/formato.js'

export default function Navbar() {
  const { totalUnidades } = usePedido()

  return (
    <header className="navbar">
      <div className="contenedor navbar-contenido">
        <Link to="/" className="logo">
          <span aria-hidden="true">🍔</span> {negocio.nombre}
        </Link>
        <nav aria-label="Principal" className="navbar-enlaces">
          <NavLink to="/" end>
            Inicio
          </NavLink>
          <NavLink to="/menu">Menú</NavLink>
          <NavLink to="/pedidos">
            Pedido
            {totalUnidades > 0 && (
              <span className="insignia" aria-label={plural(totalUnidades, 'producto')}>
                {totalUnidades}
              </span>
            )}
          </NavLink>
        </nav>
      </div>
    </header>
  )
}
