import { createContext, useContext, useEffect, useMemo, useReducer } from 'react'
import { productos } from '../data/menu.js'

const CLAVE_PEDIDO = 'el-antojo:pedido'

const PedidoContext = createContext(null)

// El estado es un objeto { idProducto: cantidad }.
function reducer(estado, accion) {
  switch (accion.type) {
    case 'agregar':
      return { ...estado, [accion.id]: (estado[accion.id] ?? 0) + 1 }
    case 'quitar': {
      const cantidad = (estado[accion.id] ?? 0) - 1
      if (cantidad > 0) return { ...estado, [accion.id]: cantidad }
      const { [accion.id]: _, ...resto } = estado
      return resto
    }
    case 'eliminar': {
      const { [accion.id]: _, ...resto } = estado
      return resto
    }
    case 'vaciar':
      return {}
    default:
      return estado
  }
}

function cargarPedido() {
  try {
    const guardado = JSON.parse(localStorage.getItem(CLAVE_PEDIDO)) ?? {}
    const limpio = {}
    for (const { id } of productos) {
      if (Number.isInteger(guardado[id]) && guardado[id] > 0) limpio[id] = guardado[id]
    }
    return limpio
  } catch {
    return {}
  }
}

export function PedidoProvider({ children }) {
  const [cantidades, dispatch] = useReducer(reducer, undefined, cargarPedido)

  useEffect(() => {
    try {
      localStorage.setItem(CLAVE_PEDIDO, JSON.stringify(cantidades))
    } catch {
      // Sin almacenamiento disponible el pedido solo vive en memoria.
    }
  }, [cantidades])

  const valor = useMemo(() => {
    const items = productos
      .filter((producto) => cantidades[producto.id])
      .map((producto) => ({
        ...producto,
        cantidad: cantidades[producto.id],
        subtotal: producto.precio * cantidades[producto.id],
      }))

    return {
      items,
      cantidades,
      totalUnidades: items.reduce((suma, item) => suma + item.cantidad, 0),
      total: items.reduce((suma, item) => suma + item.subtotal, 0),
      agregar: (id) => dispatch({ type: 'agregar', id }),
      quitar: (id) => dispatch({ type: 'quitar', id }),
      eliminar: (id) => dispatch({ type: 'eliminar', id }),
      vaciar: () => dispatch({ type: 'vaciar' }),
    }
  }, [cantidades])

  return <PedidoContext.Provider value={valor}>{children}</PedidoContext.Provider>
}

export function usePedido() {
  const contexto = useContext(PedidoContext)
  if (!contexto) throw new Error('usePedido debe usarse dentro de <PedidoProvider>')
  return contexto
}
