import { Link } from 'react-router-dom'
import ProductoCard from '../components/ProductoCard.jsx'
import { negocio, productos } from '../data/menu.js'

const pasos = [
  { emoji: '👀', titulo: 'Mira el menú', texto: 'Todos los productos con su precio, sin sorpresas.' },
  { emoji: '🛒', titulo: 'Arma tu pedido', texto: 'Agrega lo que quieras y ajusta las cantidades.' },
  { emoji: '✅', titulo: 'Confirma', texto: 'Revisa el total a pagar y envía tu pedido.' },
]

export default function Inicio() {
  const destacados = productos.filter((producto) => producto.destacado)

  return (
    <>
      <section className="hero">
        <div className="contenedor hero-contenido">
          <div>
            <p className="hero-etiqueta">{negocio.lema}</p>
            <h1>
              Arma tu pedido <span>en un minuto</span>
            </h1>
            <p className="hero-texto">
              Elige lo que se te antoje y conoce el total a pagar antes de confirmar. Sin filas y
              sin papelitos.
            </p>
            <div className="hero-acciones">
              <Link to="/menu" className="boton boton-amarillo">
                Ver el menú
              </Link>
              <Link to="/pedidos" className="boton boton-borde-claro">
                Ir a mi pedido
              </Link>
            </div>
          </div>
          <div className="hero-emojis" aria-hidden="true">
            <span>🍔</span>
            <span>🍟</span>
            <span>🥤</span>
          </div>
        </div>
      </section>

      <section className="seccion contenedor">
        <h2>¿Cómo funciona?</h2>
        <ol className="pasos">
          {pasos.map((paso, indice) => (
            <li key={paso.titulo} className="paso">
              <span className="paso-emoji" aria-hidden="true">
                {paso.emoji}
              </span>
              <h3>
                {indice + 1}. {paso.titulo}
              </h3>
              <p>{paso.texto}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="seccion contenedor">
        <div className="seccion-encabezado">
          <h2>Los más pedidos</h2>
          <Link to="/menu" className="enlace">
            Ver todo el menú →
          </Link>
        </div>
        <div className="grilla-productos">
          {destacados.map((producto) => (
            <ProductoCard key={producto.id} producto={producto} />
          ))}
        </div>
      </section>
    </>
  )
}
