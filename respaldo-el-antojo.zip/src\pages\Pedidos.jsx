import { useState } from 'react'
import { Link } from 'react-router-dom'
import Cantidad from '../components/Cantidad.jsx'
import { usePedido } from '../context/PedidoContext.jsx'
import { formatoPrecio, plural } from '../utils/formato.js'

const CLAVE_NUMERO = 'el-antojo:ultimo-numero'

const entregas = [
  { id: 'aqui', nombre: 'Para comer aquí' },
  { id: 'llevar', nombre: 'Para llevar' },
]

function siguienteNumero() {
  let numero = 1
  try {
    numero = (Number(localStorage.getItem(CLAVE_NUMERO)) || 0) + 1
    localStorage.setItem(CLAVE_NUMERO, String(numero))
  } catch {
    // Sin almacenamiento disponible la numeración empieza de nuevo.
  }
  return numero
}

export default function Pedidos() {
  const { items, total, totalUnidades, agregar, quitar, eliminar, vaciar } = usePedido()
  const [nombre, setNombre] = useState('')
  const [entrega, setEntrega] = useState('aqui')
  const [notas, setNotas] = useState('')
  const [error, setError] = useState('')
  const [confirmado, setConfirmado] = useState(null)

  function confirmar(evento) {
    evento.preventDefault()
    if (!nombre.trim()) {
      setError('Escribe un nombre para llamarte cuando el pedido esté listo.')
      return
    }
    setConfirmado({
      numero: siguienteNumero(),
      nombre: nombre.trim(),
      entrega: entregas.find((opcion) => opcion.id === entrega).nombre,
      notas: notas.trim(),
      hora: new Date(),
      items,
      total,
    })
    vaciar()
  }

  if (confirmado) return <Comprobante pedido={confirmado} />

  if (items.length === 0) {
    return (
      <div className="contenedor pagina vacio">
        <span className="vacio-emoji" aria-hidden="true">
          🧾
        </span>
        <h1>Tu pedido está vacío</h1>
        <p>Agrega productos desde el menú y aquí verás el total a pagar.</p>
        <Link to="/menu" className="boton boton-primario">
          Ir al menú
        </Link>
      </div>
    )
  }

  return (
    <div className="contenedor pagina">
      <h1>Tu pedido</h1>
      <p className="pagina-intro">Revisa los productos y el total antes de confirmar.</p>

      <div className="pedido-columnas">
        <section aria-label="Productos del pedido">
          <ul className="pedido-lista">
            {items.map((item) => (
              <li key={item.id} className="pedido-item">
                <span className="pedido-item-emoji" aria-hidden="true">
                  {item.emoji}
                </span>
                <div className="pedido-item-info">
                  <h2>{item.nombre}</h2>
                  <p>{formatoPrecio(item.precio)} c/u</p>
                </div>
                <strong className="pedido-item-subtotal">{formatoPrecio(item.subtotal)}</strong>
                <div className="pedido-item-acciones">
                  <Cantidad
                    nombre={item.nombre}
                    cantidad={item.cantidad}
                    onSumar={() => agregar(item.id)}
                    onRestar={() => quitar(item.id)}
                  />
                  <button
                    type="button"
                    className="enlace enlace-peligro"
                    onClick={() => eliminar(item.id)}
                    aria-label={`Eliminar ${item.nombre} del pedido`}
                  >
                    Eliminar
                  </button>
                </div>
              </li>
            ))}
          </ul>
          <div className="pedido-lista-pie">
            <Link to="/menu" className="enlace">
              ← Agregar más productos
            </Link>
            <button type="button" className="enlace enlace-peligro" onClick={vaciar}>
              Vaciar pedido
            </button>
          </div>
        </section>

        <form className="resumen" onSubmit={confirmar} noValidate>
          <h2>Resumen</h2>

          <div className="campo">
            <label htmlFor="nombre">¿A nombre de quién?</label>
            <input
              id="nombre"
              type="text"
              autoComplete="given-name"
              placeholder="Tu nombre"
              value={nombre}
              onChange={(evento) => {
                setNombre(evento.target.value)
                setError('')
              }}
              aria-invalid={error ? 'true' : undefined}
              aria-describedby={error ? 'nombre-error' : undefined}
            />
            {error && (
              <p id="nombre-error" className="campo-error" role="alert">
                {error}
              </p>
            )}
          </div>

          <fieldset className="campo opciones">
            <legend>¿Cómo lo quieres?</legend>
            {entregas.map((opcion) => (
              <label key={opcion.id} className="opcion">
                <input
                  type="radio"
                  name="entrega"
                  value={opcion.id}
                  checked={entrega === opcion.id}
                  onChange={() => setEntrega(opcion.id)}
                />
                {opcion.nombre}
              </label>
            ))}
          </fieldset>

          <div className="campo">
            <label htmlFor="notas">
              Notas para la cocina <span className="opcional">(opcional)</span>
            </label>
            <textarea
              id="notas"
              rows="2"
              placeholder="Sin cebolla, salsas aparte…"
              value={notas}
              onChange={(evento) => setNotas(evento.target.value)}
            />
          </div>

          <dl className="total">
            <div>
              <dt>Productos</dt>
              <dd>{totalUnidades}</dd>
            </div>
            <div className="total-pagar">
              <dt>Total a pagar</dt>
              <dd>{formatoPrecio(total)}</dd>
            </div>
          </dl>

          <button type="submit" className="boton boton-primario boton-ancho">
            Confirmar pedido
          </button>
        </form>
      </div>
    </div>
  )
}

function Comprobante({ pedido }) {
  const numero = String(pedido.numero).padStart(3, '0')
  const hora = pedido.hora.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })

  return (
    <div className="contenedor pagina">
      <section className="comprobante" aria-labelledby="comprobante-titulo">
        <span className="comprobante-check" aria-hidden="true">
          ✓
        </span>
        <h1 id="comprobante-titulo">¡Pedido confirmado!</h1>
        <p>
          Gracias, {pedido.nombre}. Ya lo estamos preparando; te llamamos por tu nombre cuando esté
          listo.
        </p>

        <p className="comprobante-numero">
          Pedido <strong>#{numero}</strong>
        </p>
        <p className="comprobante-detalle">
          {pedido.entrega} · {hora} · {plural(pedido.items.reduce((s, i) => s + i.cantidad, 0), 'producto')}
        </p>

        <ul className="comprobante-lista">
          {pedido.items.map((item) => (
            <li key={item.id}>
              <span>
                {item.cantidad} × {item.nombre}
              </span>
              <span>{formatoPrecio(item.subtotal)}</span>
            </li>
          ))}
        </ul>
        {pedido.notas && <p className="comprobante-notas">Notas: {pedido.notas}</p>}
        <p className="comprobante-total">
          <span>Total a pagar</span>
          <strong>{formatoPrecio(pedido.total)}</strong>
        </p>

        <div className="comprobante-acciones">
          <Link to="/menu" className="boton boton-primario">
            Hacer otro pedido
          </Link>
          <Link to="/" className="boton boton-borde">
            Volver al inicio
          </Link>
        </div>
      </section>
    </div>
  )
}
