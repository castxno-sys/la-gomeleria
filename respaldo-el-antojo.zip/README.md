# El Antojo · Comidas rápidas

Prototipo funcional en React para que los clientes de un negocio de comidas rápidas vean el menú, armen su pedido y conozcan el total a pagar antes de confirmarlo.

## Cómo ejecutarlo

Necesitas [Node.js](https://nodejs.org) 20 o superior.

```bash
npm install
npm run dev
```

Luego abre la dirección que muestra la terminal (normalmente http://localhost:5173).

## Rutas

| Ruta       | Página                                                                 |
| ---------- | ---------------------------------------------------------------------- |
| `/`        | Inicio: presentación, cómo funciona y productos más pedidos             |
| `/menu`    | Menú por categorías, con botones para agregar productos al pedido       |
| `/pedidos` | Pedido: cantidades, total a pagar, datos del cliente y confirmación     |

## Estructura

```
src/
  main.jsx                 Punto de entrada y BrowserRouter
  App.jsx                  Definición de rutas
  index.css                Estilos y paleta de colores
  data/menu.js             Datos del negocio, categorías y productos
  context/PedidoContext.jsx  Estado del pedido (useReducer + localStorage)
  components/              Navbar, Footer, ProductoCard, Cantidad
  pages/                   Inicio, Menu, Pedidos, NoEncontrada
  utils/formato.js         Formato de precios
```

El nombre del negocio, los productos y los precios son datos de ejemplo y se cambian en `src/data/menu.js`.
