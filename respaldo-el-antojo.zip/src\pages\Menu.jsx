import { useState } from 'react'
import { Link } from 'react-router-dom'
import ProductoCard from '../components/ProductoCard.jsx'
import { usePedido } from '../context/PedidoContext.jsx'
import { categorias, productos } from '../data/menu.js'
import { formatoPrecio, plural } from '../utils/formato.js'

export default function Menu() {
  const [filtro, setFiltro] = useState('todos')
  const { total, totalUnidades } = usePedido()

  const visibles =
    filtro === 'todos' ? categorias : categorias.filter((categoria) => categoria.id === filtro)

  return (
    <div className={`contenedor pagina ${totalUnidades > 0 ? 'con-barra' : ''}`}>
      <h1>Nuestro menú</h1>
      <p className="pagina-intro">Toca «Agregar» en lo que quieras pedir. Puedes cambiar las cantidades cuando quieras.</p>

      <div className="filtros" role="group" aria-label="Filtrar por categoría">
        <button
          type="button"
          className="filtro"
          aria-pressed={filtro === 'todos'}
          onClick={() => setFiltro('todos')}
        >
          Todo
        </button>
        {categorias.map((categoria) => (
          <button
            key={categoria.id}
            type="button"
            className="filtro"
            aria-pressed={filtro === categoria.id}
            onClick={() => setFiltro(categoria.id)}
          >
            <span aria-hidden="true">{categoria.emoji}</span> {categoria.nombre}
          </button>
        ))}
      </div>

      {visibles.map((categoria) => (
        <section key={categoria.id} className="categoria">
          <h2>
            <span aria-hidden="true">{categoria.emoji}</span> {categoria.nombre}
          </h2>
          <div className="grilla-productos">
            {productos
              .filter((producto) => producto.categoria === categoria.id)
              .map((producto) => (
                <ProductoCard key={producto.id} producto={producto} />
              ))}
          </div>
        </section>
      ))}

      {totalUnidades > 0 && (
        <div className="barra-pedido" role="status">
          <div className="contenedor barra-pedido-contenido">
            <p>
              <span>{plural(totalUnidades, 'producto')}</span>
              <strong>{formatoPrecio(total)}</strong>
            </p>
            <Link to="/pedidos" className="boton boton-amarillo">
              Ver mi pedido →
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}
