import { negocio } from '../data/menu.js'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="contenedor footer-contenido">
        <p className="footer-nombre">
          <span aria-hidden="true">🍔</span> {negocio.nombre}
        </p>
        <p>{negocio.horario}</p>
        <p>{negocio.direccion}</p>
      </div>
    </footer>
  )
}
