import { usePedido } from '../context/PedidoContext.jsx'
import { formatoPrecio } from '../utils/formato.js'
import Cantidad from './Cantidad.jsx'

export default function ProductoCard({ producto }) {
  const { cantidades, agregar, quitar } = usePedido()
  const cantidad = cantidades[producto.id] ?? 0

  return (
    <article className="producto">
      <div className="producto-imagen" aria-hidden="true">
        {producto.emoji}
      </div>
      <div className="producto-info">
        <h3>{producto.nombre}</h3>
        <p>{producto.descripcion}</p>
      </div>
      <div className="producto-pie">
        <span className="precio">{formatoPrecio(producto.precio)}</span>
        {cantidad === 0 ? (
          <button
            type="button"
            className="boton boton-primario boton-chico"
            onClick={() => agregar(producto.id)}
            aria-label={`Agregar ${producto.nombre} al pedido`}
          >
            Agregar
          </button>
        ) : (
          <Cantidad
            nombre={producto.nombre}
            cantidad={cantidad}
            onSumar={() => agregar(producto.id)}
            onRestar={() => quitar(producto.id)}
          />
        )}
      </div>
    </article>
  )
}
